-- MySQL dump 10.13  Distrib 5.6.48, for Linux (x86_64)
--
-- Host: localhost    Database: dxh
-- ------------------------------------------------------
-- Server version	5.6.48-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sys_booking`
--

DROP TABLE IF EXISTS `sys_booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_booking` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `phone` varchar(20) DEFAULT NULL,
  `message` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_booking`
--

LOCK TABLES `sys_booking` WRITE;
/*!40000 ALTER TABLE `sys_booking` DISABLE KEYS */;
INSERT INTO `sys_booking` VALUES (107,'81685894384',' \r\n<a href=https://tennis-bet.ru/olimp-promokod/>olimp промокод</a> - бонус 1xgames, промокод винлайн'),(108,'89039502879','Just one click can turn you dollar into $1000. \r\nLink - https://plbtc.page.link/zXbp'),(109,'89036938527','See how Robot makes $1000 from $1 of investment. \r\nLink - https://plbtc.page.link/zXbp'),(110,'89034782110','Your money keep grow 24/7 if you use the financial Robot. \r\nLink - https://plbtc.page.link/zXbp'),(111,'84661144684',' Всем привет! Xотел  узнать,недавно  встал вопрос  о разработке  сайта. Мой выбор был рандомным и я не прогадал. Так-вот, хотел посоветовать Вам  замечетельную компаниию  по разработке мобильных приложений  \r\nhttps://icsoft.md . Компания бесплатно консультирует начинающих IT предпринимателей по всем вопросам связанными с разработкой и созданием сайтов и мобильных приложений, а также их продвижением.'),(112,'89034044352','The online income is your key to success. \r\nLink - https://plbtc.page.link/zXbp'),(113,'89038283513','Try out the best financial robot in the Internet. \r\nLink - https://plbtc.page.link/zXbp'),(114,'89035694147','Launch the financial Bot now to start earning. \r\nLink - https://plbtc.page.link/zXbp'),(115,'82656738222',' \r\n<a href=http://gematy.ru>счастливая семейная жизнь</a>'),(116,'88255232972','<a href=http://prostitutkilov.xyz>юные сучки бляди</a> , размещенные на нашем ресурсе, настолько прекрасны, что выбор будет сделать совсем не просто, но выбрав самую развратную красотку-путану, она воплотит в реальность самые смелые сексуальные фантазии.'),(117,'89033198840','The financial Robot is your future wealth and independence. \r\nLink - https://plbtc.page.link/zXbp'),(118,'89037028157','寻找一个简单的方法来make钱？ 看看金融机器人。 \r\n链接 -  https://plbtc.page.link/zXbp'),(119,'81576926694','<a href=https://4ip.su>площадка hydra</a> - hydra onion ссылка, как зайти на гидру через тор браузер'),(120,'88219982931','первоклассный вебсайт  \r\n<a href=https://pizdeishn.net/>Крутые секс истории про жену</a>'),(121,'81858113693',' \r\n \r\nUrgently! \r\nI\'m looking for a strict sugar daddy! \r\nFor dirty and vulgar sex! \r\nMy site https://cutt.us/home2021 \r\nMy nickname milasex \r\nBe sure to confirm your mail so you can write to me! \r\n<a href=https://cutt.us/home2021><img src=\"http://skype.miss-bdsm.mcdir.ru/home/home5.jpg\"></a>'),(122,'89034841869','Even a child knows how to make $100 today with the help of this robot. \r\nLink - https://plbtc.page.link/zXbp'),(123,'88641498762','славнецкий сайт  \r\n<a href=https://sexreliz.net/enema/1220-izvrascheniya-s-shirokim-spektrom.html>https://sexreliz.net/enema/1220-izvrascheniya-s-shirokim-spektrom.html</a>'),(124,'82875865598','https://visasam.ru/emigration/pereezdsng/grazhdanstvo-moldovy.html'),(125,'89039393295','在线收入是你成功的关键。 \r\n链接 - https://plbtc.page.link/zXbp'),(126,'82769856245','https://t.me/XrumerSeo - Регистрация на форум'),(127,'89033671062','Launch the financial Bot now to start earning. \r\nLink -  https://plbtc.page.link/zXbp'),(128,'89032988382','Still not a millionaire? The financial robot will make you him! \r\nLink - https://plbtc.page.link/zXbp'),(129,'89039960375','The additional income is available for everyone using this robot. \r\nLink - https://plbtc.page.link/zXbp'),(130,'88211742347','<a href=https://rb-str.ru/>центр стерлитамак</a> - Стерлитамак, стерлитамак 2020'),(131,'89262444322','Купить цифровые версии игр XBOX ONE  + https://plati.market/itm/battlefield-1-revolution-inc-battlefield-1943-xbox-one/2921621'),(132,'89030725349','赚几千块钱 金融机器人将帮助你做到这一点！ \r\n链接 - https://plbtc.page.link/zXbp'),(133,'89035377239','为你的家人提供这笔钱的年龄。 启动机器人！ \r\n链接 -  https://plbtc.page.link/zXbp'),(134,'89031175402','Check out the newest way to make a fantastic profit. \r\nLink - https://plbtc.page.link/zXbp'),(135,'89036780272','Join the society of successful people who make money here. \r\nLink - https://plbtc.page.link/zXbp');
/*!40000 ALTER TABLE `sys_booking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_info`
--

DROP TABLE IF EXISTS `sys_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_info` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `company` varchar(50) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `telephone` varchar(80) DEFAULT NULL,
  `fax` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_info`
--

LOCK TABLES `sys_info` WRITE;
/*!40000 ALTER TABLE `sys_info` DISABLE KEYS */;
INSERT INTO `sys_info` VALUES (1,'上海帝赐自动化科技有限公司','上海市浦江镇联星村10组1号厂房','15201888232','13671919829');
/*!40000 ALTER TABLE `sys_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_product`
--

DROP TABLE IF EXISTS `sys_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_product` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `img_url` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_product`
--

LOCK TABLES `sys_product` WRITE;
/*!40000 ALTER TABLE `sys_product` DISABLE KEYS */;
INSERT INTO `sys_product` VALUES (1,'ABB机器人','https://www.dicitek.com/static/img/tj_c1.png'),(2,'库卡KUKA机器人','https://www.dicitek.com/static/img/tj_a1.png'),(3,'安川MOTOMAN机器人','https://www.dicitek.com/static/img/tj_b1.png'),(4,'发那科FANUC机器人','https://www.dicitek.com/static/img/fc.jpeg');
/*!40000 ALTER TABLE `sys_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_users`
--

DROP TABLE IF EXISTS `sys_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(25) NOT NULL DEFAULT '',
  `password` varchar(80) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_users`
--

LOCK TABLES `sys_users` WRITE;
/*!40000 ALTER TABLE `sys_users` DISABLE KEYS */;
INSERT INTO `sys_users` VALUES (1,'admin','dxh@@8888@@');
/*!40000 ALTER TABLE `sys_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-06 18:14:10
